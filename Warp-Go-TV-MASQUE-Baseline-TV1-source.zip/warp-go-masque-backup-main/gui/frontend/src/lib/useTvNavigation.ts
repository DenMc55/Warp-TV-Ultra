import { useEffect } from "react";

const SELECTOR = [
  "button:not([disabled])",
  "a[href]",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  '[tabindex]:not([tabindex="-1"])',
].join(",");

function visible(el: HTMLElement) {
  const r = el.getBoundingClientRect();
  const s = getComputedStyle(el);
  return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
}

export function useTvNavigation() {
  useEffect(() => {
    const onKeyDown = (ev: KeyboardEvent) => {
      if (!["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(ev.key)) return;
      const items = Array.from(document.querySelectorAll<HTMLElement>(SELECTOR)).filter(visible);
      if (!items.length) return;

      const current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
      if (!current || !items.includes(current)) {
        items[0].focus();
        ev.preventDefault();
        return;
      }

      const a = current.getBoundingClientRect();
      const ax = a.left + a.width / 2;
      const ay = a.top + a.height / 2;
      const vertical = ev.key === "ArrowUp" || ev.key === "ArrowDown";
      const positive = ev.key === "ArrowDown" || ev.key === "ArrowRight";

      let best: HTMLElement | null = null;
      let bestScore = Number.POSITIVE_INFINITY;
      for (const item of items) {
        if (item === current) continue;
        const b = item.getBoundingClientRect();
        const bx = b.left + b.width / 2;
        const by = b.top + b.height / 2;
        const primary = vertical ? by - ay : bx - ax;
        if ((positive && primary <= 4) || (!positive && primary >= -4)) continue;
        const secondary = vertical ? Math.abs(bx - ax) : Math.abs(by - ay);
        const score = Math.abs(primary) + secondary * 2.5;
        if (score < bestScore) {
          bestScore = score;
          best = item;
        }
      }
      if (best) {
        best.focus({ preventScroll: false });
        best.scrollIntoView({ block: "nearest", inline: "nearest" });
        ev.preventDefault();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);
}
