/**
 * Navigation model shared by the sidebar (md+) and the bottom nav (<md).
 * Pure data — unit-testable without jsdom.
 */

import { Activity, FileText, Globe, Radar, Settings, ScrollText } from "lucide-react";

export type PageKey = "status" | "rules" | "geo" | "scan" | "settings" | "logs";

export const NAV: { key: PageKey; label: string; icon: typeof Activity }[] = [
  { key: "status", label: "Status", icon: Activity },
  { key: "rules", label: "Rules", icon: FileText },
  { key: "geo", label: "GEO", icon: Globe },
  { key: "scan", label: "Scan", icon: Radar },
  { key: "settings", label: "Settings", icon: Settings },
  { key: "logs", label: "Logs", icon: ScrollText },
];

export const TITLES: Record<PageKey, string> = {
  status: "Status",
  rules: "Routing Rules",
  geo: "GEO Database",
  scan: "Edge Scan",
  settings: "Settings",
  logs: "Runtime Logs",
};
