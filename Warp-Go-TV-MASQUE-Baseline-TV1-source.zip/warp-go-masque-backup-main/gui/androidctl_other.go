//go:build !android

package main

import (
	"errors"
	"time"

	"warp/core"
)

// Android 反向 JNI 桥的桌面桩：桌面端无 VpnService，返回明确错误/零值。
func androidRequestVpnStart() error  { return errors.New("此操作仅支持 Android 版") }
func androidRequestVpnStop() error   { return nil }
func androidVpnRunning() bool        { return false }
func androidVpnLastError() string    { return "" }
func androidVpnStartTime() time.Time { return time.Time{} }
func androidVpnKernel() *core.Kernel { return nil }

// androidReloadRules 桌面桩：桌面端规则重载走 core.Server.ReloadRules
// （service.go 的 ReloadRules 在 !android 分支直接调用 Server，不走这里）。
func androidReloadRules() error { return nil }

// androidOpenExternalBrowser 桌面桩：桌面端用 Wails BrowserManager（service.go
// 的 OpenExternalBrowser 在 !android 分支直接调用，不会走到这里）。
func androidOpenExternalBrowser(url string) error { return nil }

// androidListInstalledApps 桌面桩：桌面端无 Android 包管理器，返回空切片。
func androidListInstalledApps() []InstalledApp { return nil }
