# Baseline TV Build 1

Purpose: A/B test against the original Chinese build.

Networking intentionally preserved from the original source:
- core MASQUE/QUIC logic unchanged
- DNS/routing logic unchanged
- Android VPN bridge/service unchanged
- registration/edge selection unchanged

Only TV-facing/build changes are included:
- English frontend labels/pages
- Android TV / LEANBACK launcher support
- touchscreen optional
- D-pad spatial focus helper + visible focus outline
- armeabi-v7a build support in addition to arm64-v8a/x86_64
- app label changed to Warp Go TV Baseline

Back-button/VPN lifecycle is intentionally left exactly as original for this diagnostic build.
