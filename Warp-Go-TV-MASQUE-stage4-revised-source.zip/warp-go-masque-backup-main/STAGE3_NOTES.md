# Warp Go TV MASQUE Stage 3

Changes:
- Retry Android VpnService.protect() when service readiness races occur (100/250/500 ms backoff).
- English diagnostics for direct-socket protection/retry failures.
- Runtime log pane is D-pad focusable and scrollable; manual scrolling disables auto-scroll.
- Cloudflare edge-port preference setting: 4500 (TV default/recommended), 443, or Auto.
- Stage 2 dark-TV, Back/background behaviour, automatic registration, ARM64 and ARMv7 support retained.
- Removed stale unused theme MODES declaration so frontend builds without the Stage 2 workflow sed workaround.
