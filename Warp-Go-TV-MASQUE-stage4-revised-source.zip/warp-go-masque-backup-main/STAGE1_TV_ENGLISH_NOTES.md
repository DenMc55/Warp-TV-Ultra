# Stage 1 - English + Android TV / Fire TV conversion

Changes in this working source:

- Renamed Android launcher label to **Warp Go TV**.
- Added Android TV / Fire TV launcher support with `LEANBACK_LAUNCHER`.
- Marked touchscreen as optional so TV devices are eligible.
- Added React/WebView D-pad spatial navigation for Up/Down/Left/Right.
- Added a high-visibility amber focus outline for TV remotes.
- Converted the main React UI and common Android/Go runtime messages to English.
- Added `armeabi-v7a` to Android ABI filters.
- Added an ARMv7 c-shared build step to the GitHub Android release workflow, alongside arm64-v8a and x86_64.

## Important compatibility point

The original source only packaged `arm64-v8a` and `x86_64`. Older Fire TV hardware that requires 32-bit ARM could therefore reject the APK before launch. This stage adds an `armeabi-v7a` path specifically to address that.

## Verification status

Source-level checks were completed. A local frontend build could not be completed in the current sandbox because installing the npm dependency tree timed out; GitHub Actions remains the intended full build environment for this project.
