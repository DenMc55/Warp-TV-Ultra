# Warp Go TV Ultra Test 2 — dual ABI baseline

Purpose: preserve the Test 1 Chinese MASQUE/gVisor networking baseline while allowing installation on both modern 64-bit Android devices and older 32-bit Fire TV devices.

- Android APK ABIs: armeabi-v7a + arm64-v8a
- Separate applicationId: com.callacat.warpgo.ultra.test
- Launcher/app title: Warp Go TV Ultra Test 2
- Version: 0.2.0
- Networking core: unchanged from Test 1
- UI language target: English
