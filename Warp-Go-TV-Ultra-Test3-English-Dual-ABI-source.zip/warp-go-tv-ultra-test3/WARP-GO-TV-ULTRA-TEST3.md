Warp Go TV Ultra Test 3

Changes from Test 2:
- User-facing Wails/React frontend translated to English.
- App label updated to Warp Go TV Ultra Test 3.
- Dual ABI retained: armeabi-v7a + arm64-v8a.
- MASQUE/gVisor/networking core intentionally unchanged from Test 2.
