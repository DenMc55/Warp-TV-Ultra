# Warp Go TV Ultra Test 1 — armeabi-v7a baseline

Purpose: prove the existing Chinese MASQUE/gVisor networking architecture on 32-bit ARM Fire TV hardware before UI refactoring.

Changes from upstream snapshot:
- Android APK ABI: armeabi-v7a only
- Go JNI library: GOARCH=arm, GOARM=7
- Separate applicationId: com.callacat.warpgo.ultra.test
- Launcher/app title: Warp Go TV Ultra Test 1
- Networking, MASQUE, gVisor, MTU and routing logic intentionally unchanged

This test deliberately preserves the original networking core. If it is stable on the older Firestick, the next stage can replace the UI with the English TV-first interface and add Android per-app exclusions.
